import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-browsing-history',
  templateUrl: './browsing-history.component.html',
  styleUrls: ['./browsing-history.component.css']
})
export class BrowsingHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
