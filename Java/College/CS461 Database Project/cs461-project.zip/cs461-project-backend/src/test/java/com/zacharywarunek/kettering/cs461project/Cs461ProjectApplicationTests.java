package com.zacharywarunek.kettering.cs461project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs461ProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
