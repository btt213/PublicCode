package com.zacharywarunek.kettering.cs461project.config;

public class Constants {

    public static final long ACCESS_TOKEN_VALIDITY_SECONDS = 5*60*60;
    public static final String SIGNING_KEY = "DQEAuiBDUI#YG345AEDAD^7&98&Y5f&^%$f&F";
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
}
